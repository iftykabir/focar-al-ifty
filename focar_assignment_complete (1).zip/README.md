# FoCar assignment

Files:
- `main.py`: driving sequence
- `focar.py`: motor and LED functions

Before running, check motor pin assignments and direction values against your course setup. Test in an open area and calibrate `DRIVE_TIME` and `TURN_TIME`. The times are estimates; they do not guarantee an exact one-metre distance or a precise return.
