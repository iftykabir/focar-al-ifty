from machine import Pin, PWM

# Motor pins for the FoCar
left_pwm = PWM(Pin(28))
left_dir = Pin(27, Pin.OUT)
right_pwm = PWM(Pin(26))
right_dir = Pin(22, Pin.OUT)

left_pwm.freq(1000)
right_pwm.freq(1000)

SPEED = 40000  # Adjust between 0 and 65535

led = Pin("LED", Pin.OUT)

def forward():
    left_dir.value(0)
    right_dir.value(0)
    left_pwm.duty_u16(SPEED)
    right_pwm.duty_u16(SPEED)

def backward():
    left_dir.value(1)
    right_dir.value(1)
    left_pwm.duty_u16(SPEED)
    right_pwm.duty_u16(SPEED)

def turn_left():
    left_dir.value(1)
    right_dir.value(0)
    left_pwm.duty_u16(SPEED)
    right_pwm.duty_u16(SPEED)

def turn_right():
    left_dir.value(0)
    right_dir.value(1)
    left_pwm.duty_u16(SPEED)
    right_pwm.duty_u16(SPEED)

def stop():
    left_pwm.duty_u16(0)
    right_pwm.duty_u16(0)

def led_on():
    led.on()

def led_off():
    led.off()
