from time import sleep
from focar import forward, backward, turn_left, turn_right, stop, led_on, led_off

# Starting estimates only: calibrate on your own FoCar.
# Adjust this until the car travels approximately one metre.
DRIVE_TIME = 2.5
TURN_TIME = 0.8

led_on()

# 1. Drive forward approximately one metre
forward()
sleep(DRIVE_TIME)
stop()
sleep(0.5)

# 2. Three-point turn
# First move forward while steering/pivoting left
forward()
turn_left()
sleep(TURN_TIME)
stop()
sleep(0.3)

# Reverse while turning right
backward()
turn_right()
sleep(TURN_TIME)
stop()
sleep(0.3)

# Move forward while turning left to face back
forward()
turn_left()
sleep(TURN_TIME)
stop()
sleep(0.5)

# 3. Return approximately to the starting point
forward()
sleep(DRIVE_TIME)
stop()

led_off()
